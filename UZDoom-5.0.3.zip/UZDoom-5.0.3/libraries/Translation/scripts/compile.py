#!/usr/bin/env python3

"""
Builds language files
"""

import re
import sys
import csv
import json
import argparse
from pathlib import Path

from libs import polib
from config import \
    DEBUG, \
    DISABLED, \
    ENABLED, \
    KEEP_REMARKS, \
    RECIPES, \
    SOURCE_LANG, \
    SOURCE_LANG_ALT, \
    THRESHOLD


def dump_csv(destination, table):
    """Writes the matrix table to a CSV file at the specified destination."""

    with open(destination, mode='w', newline='', encoding='utf-8') as file:
        csv.writer(file).writerows(table)


def remap(s, utf):
    """
    Prepares string for table
    """

    s = s.rstrip()

    # Maps proper chars to chars/sequences that uzdoom can understand.
    # This is temporary, and eventually everything in here will be removed.

    if utf:
        return s

    return s\
        .replace("™", "(TM)")\
        .replace("®", "(R)")\
        .replace("©", "(C)")\
        .replace("…", "...")\
        .replace("“", "\"")\
        .replace("”", "\"")\
        .replace("‘", "'")\
        .replace("’", "'")\
        .replace("‐", "-")\
        .replace("–", "-")\
        .replace("—", "-")\
        .replace("×", "x")\
        .replace(" ", " ")


def fill_dict(path):
    """Parses a .po file into a dictionary of translation data and metadata."""

    po = polib.pofile(path)

    meta = {}
    data = {}

    meta["id"] = po.metadata["Language"]

    # used to alert something when wrong
    meta["valid"] = True

    # for now uzdoom needs the top left cell to be "default"
    if meta["id"] == SOURCE_LANG or meta["id"] == SOURCE_LANG_ALT:
        meta["id"] = "default"

    # If we are using unifont instead of doom's font
    has_utf = meta["id"] in ["ja", "ko", "zh_Hans", "zh_Hant"]

    def add_entry(e_id, e_str, e_filter, e_comment):
        """add the specific entry to the map"""
        specific_id = e_id
        entry = {"id": e_id}
        if e_str:
            entry["string"] = remap(e_str, has_utf)
        if e_comment:
            entry["remarks"] = e_comment
        if e_filter:
            # filters are used to change strings in certain cases
            entry["filter"] = e_filter
            specific_id = f"{specific_id}#{e_filter}"

        if specific_id in data:
            if meta["valid"]:
                print(f"in: {path}")
            meta["valid"] = False
            print(f"redefining: {specific_id} as '{entry['string']}'")
            return

        data[specific_id] = entry

    alt_pattern = re.compile('(.*){(.*)\\|(.*)}(.*)')
    # loop through each entry in a language, and add to map
    for e in po:
        alt_match = alt_pattern.match(e.msgid)
        if alt_match:
            id1 = alt_match.group(1) + alt_match.group(2) + alt_match.group(4)
            id2 = alt_match.group(1) + alt_match.group(3) + alt_match.group(4)
            str1 = str2 = e.msgstr
            alt_match = alt_pattern.match(e.msgstr)
            if alt_match:
                str1 = alt_match.group(
                    1) + alt_match.group(2) + alt_match.group(4)
                str2 = alt_match.group(
                    1) + alt_match.group(3) + alt_match.group(4)
            add_entry(id1, str1, e.msgctxt, e.tcomment)
            add_entry(id2, str2, e.msgctxt, e.tcomment)
        else:
            add_entry(e.msgid, e.msgstr, e.msgctxt, e.tcomment)

    return {"data": data, "meta": meta}


def get_po_files(po_paths):
    """Validates directories and aggregates parsed
    data for all language files."""

    failed = False

    languages = {}
    po_files = []
    for po_path in po_paths:
        if not po_path.is_dir():
            failed = True
            print(f"{po_path} not a folder")
            continue

        _po_files = {}
        # find each po file in the dir, add to dict using the filename
        for f in po_path.iterdir():
            if f.is_file() and str(f).endswith(".po"):

                po_id = f.parts[-1][0:-3]
                _po_files[po_id] = fill_dict(f)

                if not _po_files[po_id]["meta"]["valid"]:
                    failed = True

                if po_id not in languages:
                    languages[po_id] = _po_files[po_id]["meta"]["id"]

                if languages[po_id] != _po_files[po_id]["meta"]["id"]:
                    failed = True
                    la = languages[po_id]
                    lb = _po_files[po_id]['meta']['id']
                    print(f"inconsistent language mapping {la} / {lb}")
                    break
        if failed:
            continue

        if SOURCE_LANG not in _po_files:
            failed = True
            po_path = str(po_path / f"{SOURCE_LANG}.po")
            print(f"{po_path} not found")
            continue

        po_files += [_po_files]

    if failed:
        return None

    languages = sorted([v for k, v in languages.items() if k != SOURCE_LANG])
    return {
        "files": po_files,
        "languages": languages
    }


def build_matrix(languages, po_files):
    """Aligns translations from different languages into a
    keyed matrix for CSV output."""

    matrix = {}

    for files in po_files:
        current = files[SOURCE_LANG]
        _matrix = {}

        for k in current["data"]:
            if k in matrix:
                print(f"Duplicate key {k}")
            v = current["data"][k]
            _matrix[k] = [
                v["string"] if "string" in v else "",
                v["id"],
                v["remarks"] if "remarks" in v and KEEP_REMARKS else "",
                v["filter"] if "filter" in v else ""
            ]

        files = {files[f]["meta"]["id"]: files[f]
                 for f in files if f != SOURCE_LANG}
        files = [files[f]["data"] if f in files else {} for f in languages]

        for k in _matrix:
            for f in files:
                tmp = [f[k]["string"] if (k in f and "string" in f[k]) else ""]
                _matrix[k] += tmp
            matrix[k] = _matrix[k]

    return matrix


def postprocess_matrix(languages, matrix):
    """make the matrix smaller"""

    if not matrix:
        return [languages, matrix]

    if DEBUG:
        notfound = [v for v in ENABLED + DISABLED if v not in languages]
        if notfound:
            print(notfound)

    langcount = len(matrix)
    tally = [0 for _ in languages]
    skip = 3  # default, remarks, filter

    for k in matrix:
        v = matrix[k]
        for i in range(skip, len(v)):
            if v[i]:
                tally[i - skip - 1] += 1
            # just use the fallback
            if v[i] == v[0]:
                v[i] = ""

    progress = {} if DEBUG else None
    for i, v in enumerate(tally):
        v /= langcount
        m = 1 * (languages[i] in ENABLED) - 1 * (languages[i] in DISABLED)
        tally[i] = (v + m) >= THRESHOLD
        if DEBUG:
            _a = f"{v:.2f}".lstrip('0')[:3]
            _b = (v >= THRESHOLD) * 1
            progress[languages[i]] = f"{_a}={_b}{m:+}"
    languages = [languages[i] for i in range(len(tally)) if tally[i]]
    tally = [True for i in range(skip + 1)] + tally
    if DEBUG:
        print(json.dumps(progress, separators=(',', ':')))

    for k in matrix:
        matrix[k] = [
            v for i, v in enumerate(
                matrix[k]) if tally[i]]

    return [languages, matrix]


def modify_globals(args):
    """Edits globals based on command line args"""

    if args.threshold is not None:
        globals()["THRESHOLD"] = min(max(0, args.threshold), 1)

    if args.all:
        globals()["DISABLED"] = []


def main(args):
    """loading, matrix building, CSV export"""

    modify_globals(args)

    root_dir = Path(__file__).parent.parent

    po_files = RECIPES[args.recipe] if args.recipe in RECIPES else None
    po_files = po_files and get_po_files([root_dir / f for f in po_files])

    if not po_files:
        if po_files is None:
            print(__doc__)
            print(f"Available recipes: {' '.join(RECIPES.keys())}")
            sys.exit(1)
        print("Empty preset")
        return

    languages = po_files["languages"]
    po_files = po_files["files"]

    matrix = build_matrix(languages, po_files)
    [languages, matrix] = postprocess_matrix(languages, matrix)

    source_id = po_files[0][SOURCE_LANG]["meta"]["id"]
    header = [source_id, "Identifier", "Remarks", "Filter"] + languages

    table = [header] + [matrix[k] for k in sorted(matrix)]

    if not KEEP_REMARKS:
        table = [r[0:2] + r[3:] for r in table]

    dump_csv(args.output, table)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        prog=Path(__file__).name,
        description=__doc__)

    parser.add_argument(
        "--recipe",
        required=True,
        help='Collection of components to compile')
    parser.add_argument(
        "--output",
        required=True,
        type=Path,
        help='File to write to')
    parser.add_argument(
        "--threshold",
        type=float,
        help='How complete a translation needs to be, in order to keep it')
    parser.add_argument(
        '--all',
        action='store_true',
        help='Consider all languages, even those that have been disabled')

    main(parser.parse_args(sys.argv[1:]))
